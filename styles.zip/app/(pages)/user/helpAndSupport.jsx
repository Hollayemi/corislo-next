import React from 'react'

const HelpAndSupport = () => {
  return (
    <div>HelpAndSupport</div>
  )
}

export default HelpAndSupport