import React from 'react'

const StoreLocation = () => {
  return (
    <div>StoreLocation</div>
  )
}

export default StoreLocation