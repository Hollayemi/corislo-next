import React from 'react'

const AllBusinesses = () => {
  return (
    <div>AllBusinesses</div>
  )
}

export default AllBusinesses