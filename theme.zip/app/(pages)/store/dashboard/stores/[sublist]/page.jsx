"use client";
import StorePage from "../page";

export default StorePage;