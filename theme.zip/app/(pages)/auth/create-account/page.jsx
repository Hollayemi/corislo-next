const Account = () => {
  return (
    <div className='h-10 leading-10 bg-slate-800 text-white font-bold text-center text-md'>Account</div>
  )
}

export default Account