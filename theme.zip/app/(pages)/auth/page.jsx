const Index = () => {
  return (
    <div className='h-10 leading-10 bg-slate-800 text-white font-bold text-center text-md'>Index</div>
  )
}

export default Index