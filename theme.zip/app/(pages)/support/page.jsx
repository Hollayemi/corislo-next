"use client";

import { SecurityTypeCard } from "@/app/components/cards/homeCards";
import IconifyIcon from "@/app/components/icon";
import HomeWrapper from "@/app/components/wrapper/Home/page";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Button,
  MenuItem,
  Select,
  TextField,
  Typography,
} from "@mui/material";

import { faqData } from "@/app/data/home/faq"
import { useState } from "react";

const SupportPage = () => {
    const [showing, setShowing] = useState(faqData[0]?.subtitles[0]?.discussion || "");
  return (
    <HomeWrapper customersReview={false}>
      <Box className="flex justify-center !my-16">
        <Box className="w-3/5 flex flex-col items-center">
          <Typography variant="body2" className="!font-black !text-3xl !mb-4">
            Help Centre
          </Typography>
          <Typography variant="caption" className="!text-[13px] text-center">
            Our support team is committed to making your Corisio experience
            smooth and hassle-free. Whether you're a buyer looking for a
            specific product or a seller aiming to optimize your storefront,
            we've got your back. Here's how we can assist you:
          </Typography>
        </Box>
      </Box>

      <Box className="flex justify-center">
        <Box className="">
          <TextField
            placeholder="Type Keyword"
            sx={{ border: 0 }}
            onChange={() => {}}
            size="small"
            className="bg-gray-200 w-80 outline-0"
          />
          <Select
            className="px-3 rounded-md bg-gray-200 !mx-3 border-1 !w-60 !h-10"
            style={{ height: 55, px: 5 }}
            onChange={() => {}}
            data-placeholder="Size"
          >
            <MenuItem value="Account & Registration">
              Account & Registration
            </MenuItem>
            <MenuItem value="User">User</MenuItem>
            <MenuItem value="Agent">Agent</MenuItem>
            <MenuItem value="Store">Store Owner</MenuItem>
          </Select>

          <Button
            variant="contained"
            className="!text-[10px] h-10 w-36 !shadow-none"
          >
            Find Query
          </Button>
        </Box>
      </Box>

      <Box className="flex justify-center">
        <SecurityTypeCard
          title="Fraud and Protection"
          image="fingerprint"
          caption="We are commited to ensuring the security and integrity of our website and protecting our users."
        />
        <SecurityTypeCard
          title="Managing my Account"
          image="lock"
          caption="Protecting your privacy and ensuring the security of your personal information is of utmost importance to us."
        />
        <SecurityTypeCard
          title="Fraud and Protection"
          image="safe"
          caption="We are here to provide you with the  information and assistance you need to effectively manage your account."
        />
      </Box>

      <Box className="flex justify-center">
        <Box className="!w-4/5 flex items-start">
          <Box className="!my-3 w-80 border-r !pr-3">
            {faqData.map((item, i) => {
              return (
                <Accordion key={i} className="!bg-transparent !shadow-none ">
                  <AccordionSummary
                    className="!border-none !outline-none !h-8"
                    expandIcon={
                      <IconifyIcon
                        fontSize="1.25rem"
                        icon="tabler:chevron-down"
                      />
                    }
                  >
                    <Typography sx={{ fontWeight: "500" }}>
                      {item.title}
                    </Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    {item.subtitles.map((each) => (
                      <Box onClick={() => setShowing(each.discussion)}>
                        <Typography sx={{ color: "text.secondary" }}>
                          {each.topic}
                        </Typography>
                      </Box>
                    ))}
                  </AccordionDetails>
                </Accordion>
              );
            })}
          </Box>
          <Box className="w-3/5 px-6">{showing}</Box>
        </Box>
      </Box>
    </HomeWrapper>
  );
};

export default SupportPage;
